/**
 * caDNAcopySoapBindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.bioconductor.rserviceJms.services.caDNAcopy;

public class caDNAcopySoapBindingImpl implements org.bioconductor.rserviceJms.services.caDNAcopy.CaDNAcopy_PortType{
    public org.bioconductor.packages.caDNAcopy.DerivedDNAcopySegment caDNAcopy(org.bioconductor.packages.caDNAcopy.DNAcopyAssays in0, org.bioconductor.packages.caDNAcopy.DNAcopyParameter in1) throws java.rmi.RemoteException {
        return null;
    }

}
