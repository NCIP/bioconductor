/**
 * CaDNAcopyResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.bioconductor.rserviceJms.services.caDNAcopy;

public class CaDNAcopyResponse  implements java.io.Serializable {
    private org.bioconductor.packages.caDNAcopy.DerivedDNAcopySegment caDNAcopyReturn;

    public CaDNAcopyResponse() {
    }

    public CaDNAcopyResponse(
           org.bioconductor.packages.caDNAcopy.DerivedDNAcopySegment caDNAcopyReturn) {
           this.caDNAcopyReturn = caDNAcopyReturn;
    }


    /**
     * Gets the caDNAcopyReturn value for this CaDNAcopyResponse.
     * 
     * @return caDNAcopyReturn
     */
    public org.bioconductor.packages.caDNAcopy.DerivedDNAcopySegment getCaDNAcopyReturn() {
        return caDNAcopyReturn;
    }


    /**
     * Sets the caDNAcopyReturn value for this CaDNAcopyResponse.
     * 
     * @param caDNAcopyReturn
     */
    public void setCaDNAcopyReturn(org.bioconductor.packages.caDNAcopy.DerivedDNAcopySegment caDNAcopyReturn) {
        this.caDNAcopyReturn = caDNAcopyReturn;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CaDNAcopyResponse)) return false;
        CaDNAcopyResponse other = (CaDNAcopyResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.caDNAcopyReturn==null && other.getCaDNAcopyReturn()==null) || 
             (this.caDNAcopyReturn!=null &&
              this.caDNAcopyReturn.equals(other.getCaDNAcopyReturn())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCaDNAcopyReturn() != null) {
            _hashCode += getCaDNAcopyReturn().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CaDNAcopyResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.bioconductor.org/services/caDNAcopy", ">caDNAcopyResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("caDNAcopyReturn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.bioconductor.org/services/caDNAcopy", "caDNAcopyReturn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://caDNAcopy.packages.bioconductor.org", "DerivedDNAcopySegment"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
