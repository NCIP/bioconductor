/**
 * CaAffyService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2RC2 Mar 03, 2006 (12:17:06 EST) WSDL2Java emitter.
 */

package org.bioconductor.rserviceJms.services.caAffy;

public interface CaAffyService extends javax.xml.rpc.Service {
    public java.lang.String getcaAffyAddress();

    public org.bioconductor.rserviceJms.services.caAffy.CaAffy getcaAffy() throws javax.xml.rpc.ServiceException;

    public org.bioconductor.rserviceJms.services.caAffy.CaAffy getcaAffy(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
