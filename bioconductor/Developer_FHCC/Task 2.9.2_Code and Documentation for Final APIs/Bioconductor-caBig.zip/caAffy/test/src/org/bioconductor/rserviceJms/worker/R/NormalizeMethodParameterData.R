NormalizeMethodParameterData <- try(new("NormalizeMethodParameter"), silent=TRUE)
if(is(NormalizeMethodParameterData, "try-error"))
	NormalizeMethodParameterData <- NULL
