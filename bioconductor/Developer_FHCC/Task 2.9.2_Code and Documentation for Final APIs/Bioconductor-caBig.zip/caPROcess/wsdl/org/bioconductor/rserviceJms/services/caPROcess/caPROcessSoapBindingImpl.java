/**
 * caPROcessSoapBindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.bioconductor.rserviceJms.services.caPROcess;

public class caPROcessSoapBindingImpl implements org.bioconductor.rserviceJms.services.caPROcess.CaPROcess_PortType{
    public org.bioconductor.packages.caPROcess.PeakLocation caPROcess(org.bioconductor.packages.caPROcess.MzAssays in0, org.bioconductor.packages.caPROcess.PROcessParameter in1) throws java.rmi.RemoteException {
        return null;
    }

}
