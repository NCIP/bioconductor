/**
 * MzAssays.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.bioconductor.packages.caPROcess;

public class MzAssays  implements java.io.Serializable {
    private java.lang.Object[] RData;

    private org.bioconductor.packages.caPROcess.MzSpectrum listTemplate;

    public MzAssays() {
    }

    public MzAssays(
           java.lang.Object[] RData,
           org.bioconductor.packages.caPROcess.MzSpectrum listTemplate) {
           this.RData = RData;
           this.listTemplate = listTemplate;
    }


    /**
     * Gets the RData value for this MzAssays.
     * 
     * @return RData
     */
    public java.lang.Object[] getRData() {
        return RData;
    }


    /**
     * Sets the RData value for this MzAssays.
     * 
     * @param RData
     */
    public void setRData(java.lang.Object[] RData) {
        this.RData = RData;
    }


    /**
     * Gets the listTemplate value for this MzAssays.
     * 
     * @return listTemplate
     */
    public org.bioconductor.packages.caPROcess.MzSpectrum getListTemplate() {
        return listTemplate;
    }


    /**
     * Sets the listTemplate value for this MzAssays.
     * 
     * @param listTemplate
     */
    public void setListTemplate(org.bioconductor.packages.caPROcess.MzSpectrum listTemplate) {
        this.listTemplate = listTemplate;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof MzAssays)) return false;
        MzAssays other = (MzAssays) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.RData==null && other.getRData()==null) || 
             (this.RData!=null &&
              java.util.Arrays.equals(this.RData, other.getRData()))) &&
            ((this.listTemplate==null && other.getListTemplate()==null) || 
             (this.listTemplate!=null &&
              this.listTemplate.equals(other.getListTemplate())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getRData() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRData());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRData(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getListTemplate() != null) {
            _hashCode += getListTemplate().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(MzAssays.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://caPROcess.packages.bioconductor.org", "MzAssays"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RData");
        elemField.setXmlName(new javax.xml.namespace.QName("http://caPROcess.packages.bioconductor.org", "RData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "anyType"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://www.bioconductor.org/services/caPROcess", "item"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("listTemplate");
        elemField.setXmlName(new javax.xml.namespace.QName("http://caPROcess.packages.bioconductor.org", "listTemplate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://caPROcess.packages.bioconductor.org", "MzSpectrum"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
