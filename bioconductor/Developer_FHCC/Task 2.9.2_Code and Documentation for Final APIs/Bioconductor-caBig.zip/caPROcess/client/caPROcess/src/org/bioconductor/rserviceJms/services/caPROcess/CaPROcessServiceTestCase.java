/**
 * CaPROcessServiceTestCase.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.bioconductor.rserviceJms.services.caPROcess;

public class CaPROcessServiceTestCase extends junit.framework.TestCase {
    public CaPROcessServiceTestCase(java.lang.String name) {
        super(name);
    }

    public void testcaPROcessWSDL() throws Exception {
        javax.xml.rpc.ServiceFactory serviceFactory = javax.xml.rpc.ServiceFactory.newInstance();
        java.net.URL url = new java.net.URL(new org.bioconductor.rserviceJms.services.caPROcess.CaPROcessServiceLocator().getcaPROcessAddress() + "?WSDL");
        javax.xml.rpc.Service service = serviceFactory.createService(url, new org.bioconductor.rserviceJms.services.caPROcess.CaPROcessServiceLocator().getServiceName());
        assertTrue(service != null);
    }

    public void test1caPROcessCaPROcess() throws Exception {
        org.bioconductor.rserviceJms.services.caPROcess.CaPROcessSoapBindingStub binding;
        try {
            binding = (org.bioconductor.rserviceJms.services.caPROcess.CaPROcessSoapBindingStub)
                          new org.bioconductor.rserviceJms.services.caPROcess.CaPROcessServiceLocator().getcaPROcess();
        }
        catch (javax.xml.rpc.ServiceException jre) {
            if(jre.getLinkedCause()!=null)
                jre.getLinkedCause().printStackTrace();
            throw new junit.framework.AssertionFailedError("JAX-RPC ServiceException caught: " + jre);
        }
        assertNotNull("binding is null", binding);

        // Time out after a minute
        binding.setTimeout(60000);

        // Test operation
        org.bioconductor.packages.caPROcess.PeakLocation value = null;
        value = binding.caPROcess(new org.bioconductor.packages.caPROcess.MzAssays(), new org.bioconductor.packages.caPROcess.PROcessParameter());
        // TBD - validate results
    }

}
