
package org.bioconductor.rserviceJms.services.caPROcess;
import junit.framework.JUnit4TestAdapter;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.Ignore;
import static org.junit.Assert.*;
import java.rmi.RemoteException;

import java.io.*;

public class caPROcessTest {
	private static caPROcess myService;

	/**
	 * Used for backward compatibility (IDEs, Ant and JUnit 3.x text runner)
	 */
	public static junit.framework.Test suite() {
		 return new JUnit4TestAdapter(caPROcessTest.class);
	}

	/**
	 * Sets up the test fixture; Called before all the tests; Called only once.
	 */
	@BeforeClass
	public static void oneTimeSetUp() throws Exception {
		myService=new caPROcess();
	}

	/**
	 * we put this test here to let caPROcessTest work right out of box.
	 */
	@Test
	public void testcaPROcessService() {
		assertNotNull(myService);
	}

	/**
	 * Tests caPROcess.caPROcess using real data sets
	 */
	
	// 	@Ignore("please initialize function parameters")
	@Test
	public void TestCaPROcess() throws RemoteException {
		// initialize mzAssays here.
		org.bioconductor.packages.caPROcess.MzAssays caPROcess_mzAssays = null;
		try {

			String jDataFile = getClass().getResource("../../worker/Data/spectrumName.Data").getFile();
			FileInputStream fin  = new FileInputStream(jDataFile);
			ObjectInputStream oin = new ObjectInputStream(fin);
			String[] spectrumName = (String[]) oin.readObject();
			//System.out.println(spectrumName[0]);
    		
			jDataFile = getClass().getResource("../../worker/Data/intensity.Data").getFile();
			fin  = new FileInputStream(jDataFile);
			oin = new ObjectInputStream(fin);
			org.bioconductor.packages.rservices.RJNumericMatrix intensity = (org.bioconductor.packages.rservices.RJNumericMatrix) oin.readObject();
			//System.out.println(intensity.getDim()[0]);
			//System.out.println(intensity.getValue()[0]);
    		
			jDataFile = getClass().getResource("../../worker/Data/mzRatio.Data").getFile();
			fin  = new FileInputStream(jDataFile);
			oin = new ObjectInputStream(fin);
			org.bioconductor.packages.rservices.RJNumericMatrix mzRatio = (org.bioconductor.packages.rservices.RJNumericMatrix) oin.readObject();
			//System.out.println(mzRatio.getValue()[0]);
		
			Object[] rData = new Object[spectrumName.length];
			org.bioconductor.packages.caPROcess.MzSpectrum mzSpec = null;
			int[] mzDim = intensity.getDim();
			for (int j=0; j < mzDim[1]; ++j) {
				double[] mzRatio_j = new double[mzDim[0]];
				double[] intensity_j = new double[mzDim[0]];
				for (int k=0; k < mzDim[0]; ++k) {
					int index = j * mzDim[0] + k;
					intensity_j[k] = intensity.getValue()[index];
					mzRatio_j[k] = mzRatio.getValue()[index];
				}
				String[] spectrumName_j = new String[] {spectrumName[j]};
				mzSpec = new org.bioconductor.packages.caPROcess.MzSpectrum(spectrumName_j, mzRatio_j, intensity_j);
				rData[j] = mzSpec;
			}
			caPROcess_mzAssays = new org.bioconductor.packages.caPROcess.MzAssays(rData, mzSpec);
		} catch (Exception ex) {
		    throw (RemoteException) ex;
		}
    
		// initialize proCessParameter here.
		org.bioconductor.packages.caPROcess.PROcessParameter caPROcess_proCessParameter = new
		    org.bioconductor.packages.caPROcess.PROcessParameter(new double[] { 1500. },
									 new double[] {},
									 new double[] {},
									 new double[] {},
									 new double[] {},
									 new double[] {},
									 new double[] {});
		// initialize expected result here.
		org.bioconductor.packages.caPROcess.PeakLocation ans =
		    myService.caPROcess(caPROcess_mzAssays, caPROcess_proCessParameter);
    
		System.out.println(ans.getSpectrumName().length);
		System.out.println(ans.getPeakNumberInSpectrum().length);
		System.out.println(ans.getSubstanceMassAtIntensity()[4]);
		
		assertEquals(71, ans.getSpectrumName().length);
		assertEquals(71, ans.getPeakNumberInSpectrum().length);
		assertEquals(3422.63, ans.getSubstanceMassAtIntensity()[4], 0.01);
	}
	
}
