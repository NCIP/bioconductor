load('7-in-1.Rdata')
library(MassSpecWavelet)
library(RWebServices)

###################################
## produce testing data

spectrumName <- experimentInfo$Spectrum.name
mz <- MassSpecWavelet:::i2u(1:ncol(mRaw))
selInd <- 1:3
temp <- matrix(as.double(t(mRaw[selInd,])), nrow=length(mz))
intensity <- new("NumericMatrix", temp)
temp <- matrix(as.double(rep(mz,length(selInd))), nrow=length(mz))
mzRatio <- new("NumericMatrix", temp)
spectrumName <- spectrumName[selInd]


save(spectrumName,file="spectrumName.rda")
save(intensity,file="intensity.rda")
save(mzRatio,file="mzRatio.rda")



###################################
## testing
library(caPROcess)

mz.assay <-  NULL
for (i in 1:length(selInd)) {
	mzSpec.i <- new("MzSpectrum", spectrumName=spectrumName[i], mzRatio=mzRatio[,i], intensity=intensity[,i])
	mz.assay  <- c(mz.assay , list(mzSpec.i))
}
mzAssays <- new("MzAssays")
mzAssays@.Data <- mz.assay
mzAssays@listTemplate <- mzSpec.i

system.time(res <- caPROcess(mzAssays, proCessParameter=new("PROcessParameter", renormalizationCutoff=1500.)))

#  user  system elapsed 
# 60.206  31.259  92.645 

