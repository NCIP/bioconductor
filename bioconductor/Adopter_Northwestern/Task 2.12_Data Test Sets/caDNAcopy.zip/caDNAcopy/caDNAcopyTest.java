
package org.bioconductor.rserviceJms.services.caDNAcopy;
import junit.framework.JUnit4TestAdapter;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.Ignore;
import static org.junit.Assert.*;
import java.rmi.RemoteException;
import java.io.*;


public class caDNAcopyTest {
	private static caDNAcopy myService;

	/**
	 * Used for backward compatibility (IDEs, Ant and JUnit 3.x text runner)
	 */
	public static junit.framework.Test suite() {
		 return new JUnit4TestAdapter(caDNAcopyTest.class);
	}

	/**
	 * Sets up the test fixture; Called before all the tests; Called only once.
	 */
	@BeforeClass
	public static void oneTimeSetUp() throws Exception {
		myService=new caDNAcopy();
	}

	/**
	 * we put this test here to let caDNAcopyTest work right out of box.
	 */
	@Test
	public void testcaDNAcopyService() {
		assertNotNull(myService);
	}

	/**
	 * Tests caDNAcopy.caDNAcopy using real data set
	 */
	// 	@Ignore("please initialize function parameters")
	@Test
	public void TestCaDNAcopy() throws RemoteException {
		// initialize dnacopyAssays here.
		org.bioconductor.packages.caDNAcopy.DNAcopyAssays caDNAcopy_dnacopyAssays = null;
		try {
		    String jDataFile = getClass().getResource("../../worker/Data/chromosomeId.Data").getFile();
		    FileInputStream fin  = new FileInputStream(jDataFile);
		    ObjectInputStream oin = new ObjectInputStream(fin);
			int[] chromosomeId = (int[]) oin.readObject();
			System.out.println(chromosomeId[0]);
			// org.bioconductor.packages.rservices.RInteger chromosomeId = (org.bioconductor.packages.rservices.RInteger) oin.readObject();
			//System.out.println(chromosomeId.getValue()[0]);
			
		   jDataFile = getClass().getResource("../../worker/Data/logratioValues.Data").getFile();
		   fin  = new FileInputStream(jDataFile);
		   oin = new ObjectInputStream(fin);
		   org.bioconductor.packages.rservices.RJNumericMatrix logratioValues = (org.bioconductor.packages.rservices.RJNumericMatrix) oin.readObject();
		   System.out.println(logratioValues.getValue()[0]);
		   //org.bioconductor.packages.rservices.RJNumericMatrix logratioValues = (org.bioconductor.packages.rservices.RJNumericMatrix) oin.readObject();
		   
		   jDataFile = getClass().getResource("../../worker/Data/mapLocation.Data").getFile();
		   fin  = new FileInputStream(jDataFile);
		   oin = new ObjectInputStream(fin);
		   int[] mapLocation = (int[]) oin.readObject();
		   System.out.println(mapLocation[0]);
		   // org.bioconductor.packages.rservices.RInteger mapLocation = (org.bioconductor.packages.rservices.RInteger) oin.readObject();
		   //System.out.println(mapLocation.getValue()[0]);
        
		   jDataFile = getClass().getResource("../../worker/Data/sampleNames.Data").getFile();
		   fin  = new FileInputStream(jDataFile);
		   oin = new ObjectInputStream(fin);
		   String[] sampleNames = (String[]) oin.readObject();
		   System.out.println(sampleNames[0]);
		   // org.bioconductor.packages.rservices.RChar sampleNames = (org.bioconductor.packages.rservices.RChar) oin.readObject();
		   // System.out.println(sampleNames.getValue()[0]);
		   
		   caDNAcopy_dnacopyAssays = new org.bioconductor.packages.caDNAcopy.DNAcopyAssays(logratioValues, sampleNames, chromosomeId, mapLocation);
		   // caDNAcopy_dnacopyAssays = new org.bioconductor.packages.caDNAcopy.DNAcopyAssays(logratioValues, (String[]) sampleNames.getValue(), (int[]) chromosomeId.getValue(), (int[]) mapLocation.getValue());
		
		} catch (Exception ex) {
		    throw new RemoteException(ex.getMessage());
		}
    
		// initialize dnacopyParameter here.
		org.bioconductor.packages.caDNAcopy.DNAcopyParameter caDNAcopy_dnacopyParameter =
		     new org.bioconductor.packages.caDNAcopy.DNAcopyParameter(new int[] { 123 },
		 							     new double[] { 0.01 },
		 							     new int[] { 1000 },
		 							     new double[] { 0.05 });
		 org.bioconductor.packages.caDNAcopy.DerivedDNAcopySegment ans =
		     myService.caDNAcopy(caDNAcopy_dnacopyAssays, caDNAcopy_dnacopyParameter);
		 double sumMarkers=0., sumSegs=0.;
		 for (int i=0;i<ans.getSampleId().length;++i) {
		     sumSegs += ans.getAverageSegmentValue()[i];
		     sumMarkers += ans.getMarkersPerSegment()[i];
		 }
		 System.out.println("sum of all Segments:" + sumSegs);
		 System.out.println("sum of all Markers:" + sumMarkers);
		
		assertEquals(92.6523, sumSegs, 0.001);
		assertEquals(830050, sumMarkers, 1.0);
	}
	
}
