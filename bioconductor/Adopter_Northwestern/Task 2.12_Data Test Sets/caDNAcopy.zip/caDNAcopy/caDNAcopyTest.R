library(caDNAcopy)
######################################
#                  
#  prduce test data of caDNAcopy
#                  
######################################


GBMnorm <- read.csv("~dms877/caBIG/caDNAcopy/GBMnorm.csv")

selCol <- c(17:42)
selData <- GBMnorm[,selCol]
## remove na
rmInd <- apply(selData, 1, function(x) any(is.na(x)))
GBMnorm <- GBMnorm[!rmInd,]
selData <- selData[!rmInd,]

logratioValues <- new("NumericMatrix",as.matrix(selData))
save(logratioValues,file="logratioValues.rda")
sampleNames <- colnames(selData)
save(sampleNames,file="sampleNames.rda")
chromosomeId <- as.integer(GBMnorm[!rmInd,"CH"])
save(chromosomeId,file="chromosomeId.rda")
mapLocation <- as.integer(GBMnorm[!rmInd,"POS.start"])
save(mapLocation,file="mapLocation.rda")



######################################
#                  
#  test caDNAcopy  
#                  
######################################


GBM <- new("DNAcopyAssays")
GBM@logratioValues <- new("NumericMatrix",as.matrix(selData))
GBM@sampleNames <- colnames(GBMnorm)[17:42]
GBM@chromosomeId <- as.integer(GBMnorm[,"CH"])
GBM@mapLocation <- GBMnorm[,"POS.start"]


#make new DNAcopyParameter object with default values
dnacopyParameter <- new("DNAcopyParameter", randomNumberSeed=as.integer(123), changePointSignificanceLevel=0.01, 
	permutationReplicates=as.integer(1000), earlyStoppingCriterion=0.05)

#analyze using caDNAcopy and measure elapsed time
system.time(res <- caDNAcopy(GBM,dnacopyParameter))

# After removed NAs
#   user  system elapsed 
# 327.866  59.464 390.862 


sumSegs <- sum(res@averageSegmentValue)
# 92.4608

sumMarkers <- sum(res@markersPerSegment)
# 869122
