
package org.bioconductor.rserviceJms.services.caAffy;
import junit.framework.JUnit4TestAdapter;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.Ignore;
import static org.junit.Assert.*;
import java.rmi.RemoteException;

import gov.nih.nci.mageom.domain.bioassay.BioAssay;
import gov.nih.nci.mageom.domain.bioassay.BioDataCube;
import gov.nih.nci.mageom.domain.bioassay.BioDataValues;
import gov.nih.nci.mageom.domain.bioassay.DerivedBioAssay;
import gov.nih.nci.mageom.domain.bioassay.DerivedBioAssayData;

import org.bioconductor.packages.caAffy.*;
import org.bioconductor.packages.caAffy.util.MageMapper;
import org.ginkgo.labs.reader.TabFileReader;

import java.io.*;


public class caAffyTest {
	private static caAffy binding;

	private static MageMapper mapper = new MageMapper();
	static edu.columbia.geworkbench.cagrid.MageBioAssayGenerator mageBioAssayGenerator = null;

	/**
	 * Used for backward compatibility (IDEs, Ant and JUnit 3.x text runner)
	 */
	public static junit.framework.Test suite() {
		 return new JUnit4TestAdapter(caAffyTest.class);
	}

	/**
	 * Sets up the test fixture; Called before all the tests; Called only once.
	 */
	@BeforeClass
	public static void oneTimeSetUp() throws Exception {
		binding=new caAffy();
		mageBioAssayGenerator = new edu.columbia.geworkbench.cagrid.MageBioAssayGeneratorImpl();
	}


	private BioAssay[] readBioAssays(String fileName) throws FileNotFoundException {
		String lfileName = getClass().getResource(fileName).getFile();
		float[][] fdata = TabFileReader.readTabFile(new FileInputStream(lfileName));

		String[] rowNames = new String[fdata.length];
		for (int j = 0; j < rowNames.length; j++) {
			rowNames[j] = String.valueOf(j);
		}

		String[] colNames = new String[fdata[0].length];
		for (int j = 0; j < colNames.length; j++) {
			int idx = j % 26;
			colNames[j] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".substring(idx, idx+1);
		}
		return mageBioAssayGenerator.float2DToBioAssayArray(fdata, rowNames, colNames);
	}
	
	/**
	 * we put this test here to let caAffyTest work right out of box.
	 */
	@Test
	public void testcaAffyService() {
		assertNotNull(binding);
	}


	/**
	 * Tests caAffy.caExpresso
	 */
  	//@Ignore("please initialize function parameters")
	@Test
	public void TestCaExpresso() throws RemoteException, Exception {
		DerivedBioAssays derivedBioAssays = new DerivedBioAssays();
		try {
			String jDataFile = getClass().getResource("../../worker/Data/bioAssays.Data").getFile();
			FileInputStream fin  = new FileInputStream(jDataFile);
			ObjectInputStream oin = new ObjectInputStream(fin);
			org.bioconductor.packages.rservices.RJNumericMatrix bioAssays = (org.bioconductor.packages.rservices.RJNumericMatrix) oin.readObject();
			//System.out.println(bioAssays.getValue()[0]);
			derivedBioAssays.rsetBioAssays(bioAssays);	// This is the code producing OutOfMemory error
			//System.out.println(bioAssays.getValue()[0]);
		} catch (FileNotFoundException ex) {
			throw new Exception(ex.getMessage());
		}

		// initialize cdfName here.
		String[] caExpresso_cdfName = new String[] {"DrosGenome1"};

		// initialize expressoParameter here.
		org.bioconductor.packages.caAffy.ExpressoParameter caExpresso_expressoParameter = new org.bioconductor.packages.caAffy.ExpressoParameter();

		System.err.println("invoking method");
		// initialize expected result here.
		org.bioconductor.packages.caAffy.DerivedBioAssays caExpresso_ans = null;
		DerivedBioAssays ans = binding.caExpresso(derivedBioAssays,
												  caExpresso_cdfName,
												  caExpresso_expressoParameter);
		System.err.println("method invoked");
		int[] dim = mapper.getDim(ans.getBioAssays());
		assertEquals(14010, dim[0]);
		assertEquals(2, dim[1]);

		double[] exprs = mapper.getExpressionMatrix(ans.getBioAssays());
		int[] expectedSums = new int[]{8608109, 13003608};
		for (int j=0; j < dim[1]; ++j) {
			double sums = 0.;
			for (int i=0; i <dim[0]; ++i)
				sums += exprs[j * dim[0] + i];
			assertEquals(expectedSums[j], (int) sums);
		}
	}
}
