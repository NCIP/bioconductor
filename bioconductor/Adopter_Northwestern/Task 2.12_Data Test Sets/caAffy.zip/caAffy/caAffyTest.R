library(caAffy)

###################################
## produce testing data

fileList <- c('chipC-rep1.CEL', 'chipS-rep1.CEL')
## Import the raw data, affy cel files
Data <- ReadAffy(filenames=fileList)
# chip name: "DrosGenome1"
bioAssays <- exprs(Data)
bioAssays <- new("NumericMatrix", bioAssays)

save(bioAssays, file='bioAssays.Rdata')


###################################
## perform testing 

dbads <- new("DerivedBioAssays", bioAssays=bioAssays)
system.time(res <- caExpresso(dbads, Data@cdfName, new("ExpressoParameter")))

##   user  system elapsed 
## 59.492   3.639  63.537 


sum(res@bioAssays)
# 21611717

dim(res@bioAssays)
# 14010     2

colSums(res@bioAssays)
# chipC-rep1.CEL chipS-rep1.CEL 
#       8608109       13003608 
