public class CaArrayQualityMetricsClient
{
	public static final String SERVICE_URL = "http://cabig.bioconductor.org:8080/wsrf/services/cagrid/CaArrayQualityMetrics";

	public static void main(String[] args)
	{
		try{
			org.bioconductor.packages.caArrayQualityMetrics.client.CaArrayQualityMetricsClient client =
			                                                                            new org.bioconductor.packages.caArrayQualityMetrics.client.CaArrayQualityMetricsClient(SERVICE_URL);

			// Set files to be sent to the service:  (Change this to point to where the files are)
			String strTestFileDir = "/home/mtra2/TestData/GPR";
			String fileName1 = "251316214319_auto_479-628.gpr";
			String fileName2 = "251316214320_auto_478-629.gpr";

			// Create a set of FileReference to contain those files above:
			int size = 2;
			org.bioconductor.cagrid.rservices.FileReference[] fileRefArr = new org.bioconductor.cagrid.rservices.FileReference[size];

			fileRefArr[0] = new org.bioconductor.cagrid.rservices.FileReference();
			fileRefArr[0].setLocalName("251316214319_auto_479-628");
			fileRefArr[0].setType("GPR");
			fileRefArr[0].setUrl(strTestFileDir + "/" + fileName1);

			fileRefArr[1] = new org.bioconductor.cagrid.rservices.FileReference();
			fileRefArr[1].setLocalName("251316214320_auto_478-629");
			fileRefArr[1].setType("GPR");
			fileRefArr[1].setUrl(strTestFileDir+ "/" + fileName2);

			// a FileReferenceCollection to wrap the array of FileReference:
			org.bioconductor.cagrid.rservices.FileReferenceCollection fileRefCollection = new org.bioconductor.cagrid.rservices.FileReferenceCollection(fileRefArr);

			// create a session identifier for this invocation:
			org.bioconductor.cagrid.statefulservices.SessionIdentifier sessionIden = client.createQualityReportSession();

			// create a service helper to transfer FileReferenceCollection:
			org.bioconductor.packages.helper.common.HelperService helperService = new org.bioconductor.packages.helper.common.HelperService();
			// now, use helper to upload files:
			System.out.println("Transfering files...");
			helperService.uploadFileReferenceCollection(sessionIden, fileRefCollection);
			// calling the service to do report on those files:
			System.out.println("Invoking the service...");
			client.runCaArrayQualityMetrics(sessionIden);

			System.out.println("Result is ready");
			// use helper  to get the result
			org.bioconductor.cagrid.rservices.FileReferenceCollection qualityResultFileRefs = helperService.getFileReferenceCollection(sessionIden);


			System.out.println("Got the report result");
			String strDownloadTo = System.getProperty("java.io.tmpdir");  // or specify a absolute path to where you want it to download to.
			org.bioconductor.cagrid.rservices.FileReferenceCollection reportFileRefs = helperService.dowloadResultFiles(qualityResultFileRefs, strDownloadTo);

			// If everything works correctly, the result FileReferenceCollection will contain a zip file in which
			// report files created by the service exist.  So, calling displayReport in CaAQMOperationHelper will unzip and display the report.
			String reportFileLoc = reportFileRefs.getFileReferenceCollection()[0].getUrl();
			System.out.println("display report of: " + reportFileLoc);

			org.bioconductor.packages.caArrayQualityMetrics.common.CaAQMOperationsHelper.displayReport(reportFileLoc, "QMreport.html");

			}
			catch (Exception e) {
				e.printStackTrace();
			}
	}
}